# frozen_string_literal: true

module Types
  class BaseInputObject < GraphQL::Schema::InputObject
  end
end
