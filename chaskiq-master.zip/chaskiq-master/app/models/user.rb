# frozen_string_literal: true

class User < AppUser
end
