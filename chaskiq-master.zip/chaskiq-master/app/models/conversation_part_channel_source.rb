class ConversationPartChannelSource < ApplicationRecord
  belongs_to :conversation_part
end
