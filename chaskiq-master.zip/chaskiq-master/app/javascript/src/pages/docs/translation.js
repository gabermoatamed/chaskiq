export default function translation (str) {
  return str || '-- missing translation --'
}
