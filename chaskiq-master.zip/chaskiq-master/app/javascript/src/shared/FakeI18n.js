
const I18n = window.I18n

export default I18n
